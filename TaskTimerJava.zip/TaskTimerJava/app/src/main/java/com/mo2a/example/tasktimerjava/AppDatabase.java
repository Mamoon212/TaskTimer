package com.mo2a.example.tasktimerjava;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

class AppDatabase extends SQLiteOpenHelper {
    private static final String TAG = "AppDatabase";
    public static final String DATABASE_NAME= "TaskTimer.db";
    public static final int DATABASE_VERSION= 1;
    private static AppDatabase instance= null;

    private AppDatabase(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    static AppDatabase getInstance(Context context){
        if(instance == null){
            instance= new AppDatabase(context);
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        db.execSQL("CREATE TABLE Tasks (_id INTEGER PRIMARY KEY NOT NULL, Name TEXT NOT NULL, Description TEXT, SortOrder INTEGER, CategoryID INTEGER);");
        String sSQL= "create table " + TasksContract.TABLE_NAME + " ("
                +TasksContract.Columns._ID + " integer primary key not null, "
                +TasksContract.Columns.TASKS_NAME + " text not null, "
                +TasksContract.Columns.TASKS_DESCRIPTION+ " text, "
                +TasksContract.Columns.TASKS_SORTORDER+ " integer);";
        Log.d(TAG, "onCreate: "+ sSQL );
        db.execSQL(sSQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
